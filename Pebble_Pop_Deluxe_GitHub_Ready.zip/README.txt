Pebble Pop — Deluxe build
=========================

Files
- index.html: single-file game; upload this to the root of your GitHub repository.

What's improved
- Redesigned home screen and polished UI styling.
- Hidden boosters can spawn beneath placed pebbles and activate when the pebble is cleared.
- Separate background music and sound-effects toggles.
- Retains the existing GSAP animations, canvas-confetti effects, and Tone.js music engine.

Publish with GitHub Pages
1. Create or open a GitHub repository.
2. Upload index.html to the repository root and commit the change.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, then select your main branch and /(root).
5. Save and wait for GitHub Pages to publish the site.

The game uses CDN-hosted GSAP, canvas-confetti, and Tone.js libraries, so those features need an internet connection.
